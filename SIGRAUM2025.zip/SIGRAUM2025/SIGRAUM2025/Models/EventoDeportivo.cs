﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace SIGRAUM2025.Models
{
    public class EventoDeportivo
    {
        [Key]
        public int Id { get; set; }

        [MaxLength(100)]
        public string? NombreEvento { get; set; }

        [Column(TypeName = "date")]
        public DateTime? Fecha { get; set; }

        [MaxLength(100)]
        public string? Lugar { get; set; }

        [MaxLength(200)]
        public string? Descripcion { get; set; }

    }
}
