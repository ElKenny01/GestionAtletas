﻿using System.ComponentModel.DataAnnotations;

namespace SIGRAUM2025.Models
{
    public class Entrenador
    {
        [Key]
        public int Id { get; set; }

        [MaxLength(50)]
        public string? Nombre { get; set; }

        [MaxLength(50)]
        public string? Apellido { get; set; }

        [Required]
        public int IdDiciplina { get; set; }

        [MaxLength(15)]
        public string? Telefono { get; set; }

        [MaxLength(50)]
        public string? Email { get; set; }
    }
}
