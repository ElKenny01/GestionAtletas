﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace SIGRAUM2025.Models
{
    public class TipoBeca
    {
        [Key]
        public int Id { get; set; }

        [StringLength(20)]
        public string? TipoBecaNombre { get; set; }
    }
}
