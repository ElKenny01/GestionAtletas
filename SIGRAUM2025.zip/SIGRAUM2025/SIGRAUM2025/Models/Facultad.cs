﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SIGRAUM2025.Models
{
    [Table("Tbl_Facultad")]
    public class Facultad
    {

        [Key]
        public int Id { get; set; }

        public int? IdRecinto { get; set; }

        [MaxLength(50)]
        public string? NombreFacultad { get; set; }
    }
}
