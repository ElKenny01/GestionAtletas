﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace SIGRAUM2025.Models
{
    public class MetricasFisicas
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public int IdAtleta { get; set; }

        [Column(TypeName = "decimal(5,2)")]
        public decimal? AlturaCM { get; set; }

        [Column(TypeName = "decimal(5,2)")]
        public decimal? PesoKG { get; set; }

        [Column(TypeName = "decimal(5,2)")]
        public decimal? IMC { get; set; }

        [Column(TypeName = "text")]
        public string? MedidasAntropométricas { get; set; }

        [MaxLength(50)]
        public string? ResistenciaAeróbica { get; set; }

        [MaxLength(50)]
        public string? ResistenciaAnaeróbica { get; set; }

        [MaxLength(50)]
        public string? Fuerza { get; set; }

        [MaxLength(50)]
        public string? Flexibilidad { get; set; }

        [MaxLength(50)]
        public string? VelocidadReacción { get; set; }

        [MaxLength(50)]
        public string? ResultadosPruebasFísicas { get; set; }
    }
}
