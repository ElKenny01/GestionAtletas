﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace SIGRAUM2025.Models
{
    public class HistorialMedico
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public int IdAtleta { get; set; }

        [Column(TypeName = "date")]
        public DateTime? Fecha { get; set; }

        [Column(TypeName = "text")]
        public string? HistorialLesiones { get; set; }

        [MaxLength(200)]
        public string? EnfermedadesCronicas { get; set; }

        [MaxLength(200)]
        public string? Cirugias { get; set; }

        [MaxLength(200)]
        public string? PatologiasFamiliares { get; set; }

        [MaxLength(3)]
        public string? TipoSangre { get; set; }

        [Column(TypeName = "text")]
        public string? Alergias { get; set; }

        [MaxLength(100)]
        public string? ComisionMedica { get; set; }

        [MaxLength(100)]
        public string? Diagnostico { get; set; }

        [MaxLength(200)]
        public string? Observaciones { get; set; }
    }
}
