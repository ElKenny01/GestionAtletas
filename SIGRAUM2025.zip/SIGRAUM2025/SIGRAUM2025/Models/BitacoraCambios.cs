﻿using System.ComponentModel.DataAnnotations;

namespace SIGRAUM2025.Models
{
    public class BitacoraCambios
    {

        [Key]
        public int IdCambio { get; set; }

        [MaxLength(50)]
        public string? TablaAfectada { get; set; }

        public int? IdRegistroAfectado { get; set; }

        public DateTime? FechaCambio { get; set; }

        [MaxLength(50)]
        public string? UsuarioResponsable { get; set; }

        [MaxLength(200)]
        public string? DescripcionCambio { get; set; }
    }
}
