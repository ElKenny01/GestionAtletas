﻿using System.ComponentModel.DataAnnotations;

namespace SIGRAUM2025.Models
{
    public class Atleta
    {
        [Key]
        public int Id { get; set; }

        [MaxLength(10)]
        public string? Nombre1 { get; set; }

        [MaxLength(10)]
        public string? Nombre2 { get; set; }

        [MaxLength(10)]
        public string? Apellido1 { get; set; }

        [MaxLength(10)]
        public string? Apellido2 { get; set; }

        public int? Edad { get; set; }

        public bool? Genero { get; set; }

        [MaxLength(18)]
        public string? Cedula { get; set; }

        public int? Carnet { get; set; }

        public int? IdCarrera { get; set; }

        public int? AnioCursado { get; set; }

        [MaxLength(100)]
        public string? DireccionDomiciliar { get; set; }

        public int? Telefono { get; set; }

        [MaxLength(100)]
        public string? EmergenciaDireccion { get; set; }

        public int? TelefonoContacto { get; set; }

        public int? AnioEnEstudio { get; set; }

    }
}
