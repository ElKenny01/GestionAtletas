﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace SIGRAUM2025.Models
{
    [Table("Tbl_RECINTO")]
    public class RECINTO
    {

        [Key]
        public int Id { get; set; }

        [StringLength(30)]
        public string? NombreRecinto { get; set; }
    }
}
