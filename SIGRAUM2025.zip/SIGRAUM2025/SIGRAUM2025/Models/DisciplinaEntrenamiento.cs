﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace SIGRAUM2025.Models
{
    public class DisciplinaEntrenamiento
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public int IdAtleta { get; set; }

        [Required]
        [MaxLength(50)]
        public string Disciplina { get; set; }

        [MaxLength(50)]
        public string? Categoría { get; set; }

        public int? FrecuenciaEntrenamientoSemanal { get; set; }

        [Column(TypeName = "decimal(5,2)")]
        public decimal? PorcentajePuntualidad { get; set; }

        [MaxLength(20)]
        public string? NivelDedicación { get; set; }

        public int? TiempoAprendizajeSemanas { get; set; }

        public int? SesionesMínimasPorSemana { get; set; }

        [MaxLength(100)]
        public string? PlanEntrenamiento { get; set; }

        [MaxLength(20)]
        public string? NivelExperiencia { get; set; }

        [Column(TypeName = "decimal(5,2)")]
        public decimal? PorcentajeAmbidextrismo { get; set; }
    }
}
