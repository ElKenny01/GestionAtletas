﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace SIGRAUM2025.Models
{
    public class AsistenciaEntrenamiento
    {
        [Key]
        public int Id { get; set; }

        public int? IdAtleta { get; set; }

        [Column(TypeName = "date")]
        public DateTime? Fecha { get; set; }

        public bool? Presente { get; set; }

        [MaxLength(100)]
        public string? Comentarios { get; set; }

    }
}
