﻿using System.ComponentModel.DataAnnotations;

namespace SIGRAUM2025.Models
{
    public class Carrera
    {
        public int Id { get; set; }

        public int? IdFacultad { get; set; }

        [MaxLength(50)]
        public string? Nombrecarrera { get; set; }

    }
}
