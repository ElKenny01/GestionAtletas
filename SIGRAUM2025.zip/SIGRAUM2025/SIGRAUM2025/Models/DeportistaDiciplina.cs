﻿using System.ComponentModel.DataAnnotations;

namespace SIGRAUM2025.Models
{
    public class DeportistaDiciplina
    {

        [Key]
        public int Id { get; set; }

        [Required]
        public int IdAtleta { get; set; }

        [Required]
        public int IdDiciplinaDeportiva { get; set; }

    }
}
