﻿using System.ComponentModel.DataAnnotations;

namespace SIGRAUM2025.Models
{
    public class ParticipacionEvento
    {

        [Key]
        public int Id { get; set; }

        [Required]
        public int IdAtleta { get; set; }

        [Required]
        public int IdEvento { get; set; }

        [MaxLength(50)]
        public string? Resultado { get; set; }

    }
}
