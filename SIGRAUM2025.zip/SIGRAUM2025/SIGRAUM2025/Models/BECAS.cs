﻿using System.ComponentModel.DataAnnotations;

namespace SIGRAUM2025.Models
{
    public class BECAS
    {
        [Key]
        public int Id { get; set; }

        public int? Id_TipoBeca { get; set; }

        public int? IdAtleta { get; set; }

        [MaxLength(50)]
        public string? Observacion { get; set; }

    }
}
