﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace SIGRAUM2025.Models
{
    public class DesempeñoCompetencia
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public int IdAtleta { get; set; }

        public int? CombatesGanados { get; set; }

        public int? CombatesPerdidos { get; set; }

        [Column(TypeName = "decimal(5,2)")]
        public decimal? PuntuaciónPromedio { get; set; }

        [Column(TypeName = "decimal(5,2)")]
        public decimal? TécnicasEfectivasPorMin { get; set; }

        [MaxLength(50)]
        public string? TipoVictoria { get; set; }

        [Column(TypeName = "decimal(5,2)")]
        public decimal? DuraciónPromedioCombateMin { get; set; }

        [MaxLength(50)]
        public string? TipoEvento { get; set; }

        public int? CompetenciasGanadas { get; set; }

        [MaxLength(50)]
        public string? EvaluaciónTécnica { get; set; }
    }
}
