﻿using System.ComponentModel.DataAnnotations;

namespace SIGRAUM2025.Models
{
    public class DiciplinaDeportiva
    {
        [Key]
        public int Id { get; set; }

        [MaxLength(50)]
        public string? Nombre { get; set; }
    }
}
