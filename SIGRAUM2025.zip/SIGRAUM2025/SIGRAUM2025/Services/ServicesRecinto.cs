﻿namespace SIGRAUM2025.Services
{
    public class ServicesRecinto
    {

    }
}
