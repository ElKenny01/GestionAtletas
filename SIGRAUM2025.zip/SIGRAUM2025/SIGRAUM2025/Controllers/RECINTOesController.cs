﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using SIGRAUM2025.Data;
using SIGRAUM2025.Models;

namespace SIGRAUM2025.Controllers
{
    public class RECINTOesController : Controller
    {
        private readonly SIGRAUM2025Context _context;

        public RECINTOesController(SIGRAUM2025Context context)
        {
            _context = context;
        }

      

        // GET: RECINTOes/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var rECINTO = await _context.RECINTO
                .FirstOrDefaultAsync(m => m.Id == id);
            if (rECINTO == null)
            {
                return NotFound();
            }

            return View(rECINTO);
        }

        // GET: RECINTOes/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: RECINTOes/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        //public async Task<IActionResult> Create([Bind("Id,NombreRecinto")] RECINTO rECINTO)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        _context.Add(rECINTO);
        //        await _context.SaveChangesAsync();
        //        return RedirectToAction(nameof(Index));
        //    }
        //    return View(rECINTO);
        //}

        // GET: RECINTOes/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var rECINTO = await _context.RECINTO.FindAsync(id);
            if (rECINTO == null)
            {
                return NotFound();
            }
            return View(rECINTO);
        }

        // POST: RECINTOes/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,NombreRecinto")] RECINTO rECINTO)
        {
            if (id != rECINTO.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(rECINTO);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!RECINTOExists(rECINTO.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(rECINTO);
        }

        // GET: RECINTOes/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var rECINTO = await _context.RECINTO
                .FirstOrDefaultAsync(m => m.Id == id);
            if (rECINTO == null)
            {
                return NotFound();
            }

            return View(rECINTO);
        }

        // POST: RECINTOes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var rECINTO = await _context.RECINTO.FindAsync(id);
            if (rECINTO != null)
            {
                _context.RECINTO.Remove(rECINTO);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool RECINTOExists(int id)
        {
            return _context.RECINTO.Any(e => e.Id == id);
        }


        // POST: RECINTOes/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("NombreRecinto")] RECINTO recinto)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    // Llamada al procedimiento almacenado usando Entity Framework Core
                    var nombreRecintoParam = new Microsoft.Data.SqlClient.SqlParameter("@NombreRecinto", recinto.NombreRecinto ?? (object)DBNull.Value);

                    // Ejecutar el procedimiento almacenado
                    await _context.Database.ExecuteSqlRawAsync("EXEC sp_InsertarRecinto @NombreRecinto", nombreRecintoParam);

                    return RedirectToAction(nameof(Index));
                    
                }
                catch (Exception ex)
                {
                    // Manejar errores si ocurren
                    ModelState.AddModelError(string.Empty, $"Error: {ex.Message}");
                }
            }

            return View(recinto);
        }
        // GET: RECINTOes/Index
        public async Task<IActionResult> Index()
        {
            return View(await _context.RECINTO.ToListAsync());
        }
    }
}
